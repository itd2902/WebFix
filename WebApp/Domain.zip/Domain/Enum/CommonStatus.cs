﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Enum
{
    public enum CommonStatus
    {
        InActive = 0,
        Active = 1,
        Inventory =2,
        Deleted = 3
    }
}
